// API Helper Functions for Employee Management System
// This version is for files in the src/ folder

class API {
    static baseURL = '../../backend';
    
    // Generic API call method
    static async call(endpoint, options = {}) {
        const url = `${this.baseURL}/${endpoint}`;
        const defaultOptions = {
            headers: {
                'Content-Type': 'application/json',
            },
        };
        
        const config = { ...defaultOptions, ...options };
        
        try {
            const response = await fetch(url, config);
            const data = await response.json();
            
            if (!response.ok) {
                throw new Error(data.message || 'API call failed');
            }
            
            return data;
        } catch (error) {
            console.error('API Error:', error);
            throw error;
        }
    }
    
    // Authentication methods
    static async login(username, password) {
        return this.call('auth/login.php', {
            method: 'POST',
            body: JSON.stringify({ username, password })
        });
    }
    
    static async logout() {
        return this.call('auth/logout.php', {
            method: 'POST'
        });
    }
    
    static async register(userData) {
        return this.call('auth/register.php', {
            method: 'POST',
            body: JSON.stringify(userData)
        });
    }
    
    static async checkSession() {
        return this.call('auth/check_session.php');
    }
    
    // Employee methods
    static async getEmployees(page = 1) {
        return this.call(`api/employees.php?page=${page}`);
    }
    
    static async getEmployee(id) {
        return this.call(`api/employees.php?id=${id}`);
    }
    
    static async createEmployee(employeeData) {
        return this.call('api/employees.php', {
            method: 'POST',
            body: JSON.stringify(employeeData)
        });
    }
    
    static async updateEmployee(id, employeeData) {
        return this.call('api/employees.php', {
            method: 'PUT',
            body: JSON.stringify({ id, ...employeeData })
        });
    }
    
    static async deleteEmployee(id) {
        return this.call(`api/employees.php?id=${id}`, {
            method: 'DELETE'
        });
    }
    
    // Department methods
    static async getDepartments() {
        return this.call('api/departments.php');
    }
    
    static async getDepartment(id) {
        return this.call(`api/departments.php?id=${id}`);
    }
    
    static async createDepartment(departmentData) {
        return this.call('api/departments.php', {
            method: 'POST',
            body: JSON.stringify(departmentData)
        });
    }
    
    static async updateDepartment(id, departmentData) {
        return this.call('api/departments.php', {
            method: 'PUT',
            body: JSON.stringify({ id, ...departmentData })
        });
    }
    
    static async deleteDepartment(id) {
        return this.call(`api/departments.php?id=${id}`, {
            method: 'DELETE'
        });
    }
    
    // Leave methods
    static async getLeaves(employeeId = null, status = null) {
        let url = 'api/leaves.php';
        const params = new URLSearchParams();
        
        if (employeeId) params.append('employee_id', employeeId);
        if (status) params.append('status', status);
        
        if (params.toString()) {
            url += '?' + params.toString();
        }
        
        return this.call(url);
    }
    
    static async getLeave(id) {
        return this.call(`api/leaves.php?id=${id}`);
    }
    
    static async createLeave(leaveData) {
        return this.call('api/leaves.php', {
            method: 'POST',
            body: JSON.stringify(leaveData)
        });
    }
    
    static async updateLeaveStatus(id, status) {
        return this.call('api/leaves.php', {
            method: 'PUT',
            body: JSON.stringify({ id, status })
        });
    }
    
    static async deleteLeave(id) {
        return this.call(`api/leaves.php?id=${id}`, {
            method: 'DELETE'
        });
    }
    
    static async getLeaveTypes() {
        return this.call('api/leave_types.php');
    }
    
    static async createLeaveType(data) {
        return this.call('api/leave_types.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: new URLSearchParams(data)
        });
    }
    
    static async updateLeaveType(id, data) {
        return this.call(`api/leave_types.php?id=${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: new URLSearchParams(data)
        });
    }
    
    static async deleteLeaveType(id) {
        return this.call(`api/leave_types.php?id=${id}`, {
            method: 'DELETE'
        });
    }
    
    // Salary methods
    static async getSalaries(employeeId = null, monthYear = null) {
        let url = 'api/salary.php';
        const params = new URLSearchParams();
        
        if (employeeId) params.append('employee_id', employeeId);
        if (monthYear) params.append('month_year', monthYear);
        
        if (params.toString()) {
            url += '?' + params.toString();
        }
        
        return this.call(url);
    }
    
    static async getSalary(id) {
        return this.call(`api/salary.php?id=${id}`);
    }
    
    static async createSalary(salaryData) {
        return this.call('api/salary.php', {
            method: 'POST',
            body: JSON.stringify(salaryData)
        });
    }
    
    static async updateSalaryStatus(id, status) {
        return this.call('api/salary.php', {
            method: 'PUT',
            body: JSON.stringify({ id, status })
        });
    }
    
    static async deleteSalary(id) {
        return this.call(`api/salary.php?id=${id}`, {
            method: 'DELETE'
        });
    }
    
    // Dashboard methods
    static async getDashboardStats() {
        return this.call('api/dashboard_stats.php');
    }
}

// Utility functions
const Utils = {
    // Format date
    formatDate(date) {
        return new Date(date).toLocaleDateString();
    },
    
    // Format currency
    formatCurrency(amount) {
        return new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: 'USD'
        }).format(amount);
    },
    
    // Show loading spinner
    showLoading(element) {
        element.innerHTML = '<div class="loading">Loading...</div>';
    },
    
    // Show error message
    showError(element, message) {
        element.innerHTML = `<div class="error">Error: ${message}</div>`;
    },
    
    // Show success message
    showSuccess(message) {
        alert('Success: ' + message);
    },
    
    // Show error message
    showErrorAlert(message) {
        alert('Error: ' + message);
    },
    
    // Validate email
    validateEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    },
    
    // Validate required fields
    validateRequired(fields) {
        for (const field of fields) {
            if (!field.value.trim()) {
                field.focus();
                return false;
            }
        }
        return true;
    }
};

// Session management
const Session = {
    // Check if user is logged in
    async checkAuth() {
        try {
            const response = await API.checkSession();
            return response.logged_in;
        } catch (error) {
            return false;
        }
    },
    
    // Redirect to login if not authenticated
    async requireAuth() {
        const isLoggedIn = await this.checkAuth();
        if (!isLoggedIn) {
            window.location.href = '../../public/2admin.html';
            return false;
        }
        return true;
    },
    
    // Logout user
    async logout() {
        try {
            await API.logout();
            window.location.href = '../../index.html';
        } catch (error) {
            console.error('Logout error:', error);
            window.location.href = '../../index.html';
        }
    }
};
