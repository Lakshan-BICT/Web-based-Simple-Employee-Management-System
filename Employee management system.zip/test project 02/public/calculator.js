// Salary calculator: basic + (otHours * otRate) with live updates
(function () {
	function toNum(v) {
		var n = parseFloat(v);
		return isNaN(n) ? 0 : n;
	}
	function fmt(n) {
		return (Math.round(n * 100) / 100).toFixed(2);
	}

	function compute() {
		var basic = toNum(document.getElementById('basic') && document.getElementById('basic').value);
		var otHours = toNum(document.getElementById('otHours') && document.getElementById('otHours').value);
		var otRate = toNum(document.getElementById('otRate') && document.getElementById('otRate').value);
		var ot = otHours * otRate;
		var total = basic + ot;

		var resBasic = document.getElementById('resBasic');
		var resOt = document.getElementById('resOt');
		var resTotal = document.getElementById('resTotal');
		if (resBasic) resBasic.textContent = fmt(basic);
		if (resOt) resOt.textContent = fmt(ot);
		if (resTotal) resTotal.textContent = fmt(total);
		return { basic: basic, ot: ot, total: total };
	}

	function setup() {
		var form = document.getElementById('calcForm');
		var calcBtn = document.getElementById('calcBtn');
		var clearBtn = document.getElementById('clearBtn');
		var statusEl = document.getElementById('calcStatus');
		var inputs = ['basic', 'otHours', 'otRate'].map(function (id) { return document.getElementById(id); });

		function setStatus(text, ok) {
			if (!statusEl) return;
			statusEl.textContent = text || '';
			statusEl.style.color = ok ? '#16a34a' : '#dc2626';
		}

		if (inputs) {
			inputs.forEach(function (el) {
				if (!el) return;
				el.addEventListener('input', function () {
					compute();
					setStatus('', true);
				});
				el.addEventListener('keydown', function (e) {
					if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
						form && form.dispatchEvent(new Event('submit', { cancelable: true, bubbles: true }));
					}
				});
			});
		}

		if (form) {
			form.addEventListener('submit', function (e) {
				e.preventDefault();
				var values = compute();
				if (values.total <= 0) {
					setStatus('Please enter valid numbers above 0.', false);
					return;
				}
				setStatus('Calculation updated.', true);
			});
		}

		if (clearBtn) {
			clearBtn.addEventListener('click', function () {
				inputs.forEach(function (el) { if (el) el.value = ''; });
				compute();
				setStatus('Cleared.', true);
			});
		}

		// initial render
		compute();
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', setup);
	} else {
		setup();
	}
})();

