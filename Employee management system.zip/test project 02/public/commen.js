
document.addEventListener("DOMContentLoaded", function () {
  const mode = localStorage.getItem('theme');
  if (mode === 'dark') {
    document.body.classList.add('dark-mode');
  } else {
    document.body.classList.add('light-mode');
  }
});

