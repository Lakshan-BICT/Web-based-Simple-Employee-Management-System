
    (function() {
      const pwd = document.getElementById('password');
      const toggle = document.getElementById('togglePassword');
      const form = document.getElementById('loginForm');
      const u = document.getElementById('username');
      const uErr = document.getElementById('usernameError');
      const pErr = document.getElementById('passwordError');

      toggle.addEventListener('click', function () {
        const isText = pwd.type === 'text';
        pwd.type = isText ? 'password' : 'text';
        this.textContent = isText ? 'Show' : 'Hide';
        this.setAttribute('aria-pressed', String(!isText));
        this.setAttribute('aria-label', isText ? 'Show password' : 'Hide password');
      });

      function setError(input, el, message) {
        input.setAttribute('aria-invalid', 'true');
        el.textContent = message;
        el.style.display = 'block';
      }

      function clearError(input, el) {
        input.setAttribute('aria-invalid', 'false');
        el.textContent = '';
        el.style.display = 'none';
      }

      form.addEventListener('submit', function (e) {
        let valid = true;
        if (!u.value.trim()) {
          valid = false;
          setError(u, uErr, 'Username is required.');
        } else {
          clearError(u, uErr);
        }
        if (!pwd.value.trim()) {
          valid = false;
          setError(pwd, pErr, 'Password is required.');
        } else if (pwd.value.length < 6) {
          valid = false;
          setError(pwd, pErr, 'Password must be at least 6 characters.');
        } else {
          clearError(pwd, pErr);
        }
        if (!valid) e.preventDefault();
      });

      u.addEventListener('input', () => clearError(u, uErr));
      pwd.addEventListener('input', () => clearError(pwd, pErr));
    })();
  