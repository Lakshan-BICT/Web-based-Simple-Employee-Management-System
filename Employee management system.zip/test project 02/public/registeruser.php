<?php
// Employee Registration Handler
// This file handles the form submission from 8registeruser.html

require_once '../backend/config/config.php';

// Set content type to JSON for API responses
header('Content-Type: application/json');

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

// Get form data
$emp_id = $_POST['emp_id'] ?? '';
$first_name = $_POST['first_name'] ?? '';
$last_name = $_POST['last_name'] ?? '';
$gender = $_POST['gender'] ?? '';
$designation = $_POST['designation'] ?? '';
$email = $_POST['email'] ?? '';
$date_of_birth = $_POST['date_of_birth'] ?? '';
$department = $_POST['department'] ?? '';
$mobile = $_POST['mobile'] ?? '';

// Validate required fields
$required_fields = ['emp_id', 'first_name', 'last_name', 'email', 'designation', 'department'];
$missing_fields = [];

foreach ($required_fields as $field) {
    if (empty($$field)) {
        $missing_fields[] = $field;
    }
}

if (!empty($missing_fields)) {
    echo json_encode([
        'success' => false, 
        'message' => 'Missing required fields: ' . implode(', ', $missing_fields)
    ]);
    exit;
}

// Validate email format
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['success' => false, 'message' => 'Invalid email format']);
    exit;
}

try {
    $db = getDB();
    
    // Check if employee ID already exists
    $stmt = $db->prepare("SELECT id FROM employees WHERE emp_id = ?");
    $stmt->execute([$emp_id]);
    
    if ($stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'Employee ID already exists']);
        exit;
    }
    
    // Check if email already exists
    $stmt = $db->prepare("SELECT id FROM employees WHERE email = ?");
    $stmt->execute([$email]);
    
    if ($stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'Email already exists']);
        exit;
    }
    
    // Get department ID from department name
    $stmt = $db->prepare("SELECT id FROM departments WHERE dept_name = ?");
    $stmt->execute([$department]);
    $dept_result = $stmt->fetch();
    
    if (!$dept_result) {
        echo json_encode(['success' => false, 'message' => 'Department not found: ' . $department]);
        exit;
    }
    
    $department_id = $dept_result['id'];
    
    // Insert new employee
    $stmt = $db->prepare("
        INSERT INTO employees (emp_id, first_name, last_name, email, mobile, designation, department_id, hire_date) 
        VALUES (?, ?, ?, ?, ?, ?, ?, CURDATE())
    ");
    
    $result = $stmt->execute([
        $emp_id, 
        $first_name, 
        $last_name, 
        $email, 
        $mobile, 
        $designation, 
        $department_id
    ]);
    
    if ($result) {
        echo json_encode([
            'success' => true, 
            'message' => 'Employee registered successfully!',
            'employee_id' => $emp_id
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to register employee. Please try again.']);
    }
    
} catch (Exception $e) {
    error_log("Employee registration error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Registration failed. Please try again.']);
}
?>
