// Basic client-side comments with localStorage persistence
(function () {
    var STORAGE_KEY = 'hrm_comments';
	var PREFS_KEY = 'hrm_contact_prefs';

    /** @returns {Array<{id:string,role:string,name:string,message:string,timestamp:number}>} */
    function loadComments() {
        try {
            var raw = localStorage.getItem(STORAGE_KEY);
            if (!raw) return [];
            var parsed = JSON.parse(raw);
            return Array.isArray(parsed) ? parsed : [];
        } catch (e) {
            return [];
        }
    }

    /** @param {Array} comments */
    function saveComments(comments) {
        try {
            localStorage.setItem(STORAGE_KEY, JSON.stringify(comments));
        } catch (e) {
            // ignore quota errors
        }
    }

    function uid() {
        return 'c_' + Math.random().toString(36).slice(2) + Date.now().toString(36);
    }

    function formatDate(ts) {
        var d = new Date(ts);
        return d.toLocaleString();
    }

	function loadPrefs() {
		try {
			var raw = localStorage.getItem(PREFS_KEY);
			if (!raw) return {};
			var prefs = JSON.parse(raw);
			return prefs && typeof prefs === 'object' ? prefs : {};
		} catch (_) {
			return {};
		}
	}

	function savePrefs(prefs) {
		try {
			localStorage.setItem(PREFS_KEY, JSON.stringify(prefs || {}));
		} catch (_) {}
	}

    function render(comments, filterRole) {
        var list = document.getElementById('commentsList');
        var empty = document.getElementById('commentsEmpty');
        if (!list) return;

        list.innerHTML = '';
        var filtered = comments.filter(function (c) {
            if (!filterRole || filterRole === 'All') return true;
            return c.role === filterRole;
        });

        if (filtered.length === 0) {
            if (empty) empty.hidden = false;
            return;
        } else {
            if (empty) empty.hidden = true;
        }

        filtered.sort(function (a, b) { return b.timestamp - a.timestamp; });

        filtered.forEach(function (c) {
            var li = document.createElement('li');
            li.className = 'comment-item';

            var header = document.createElement('div');
            header.className = 'comment-header';
            header.textContent = c.role + ' • ' + (c.name || 'Anonymous');

            var time = document.createElement('div');
            time.className = 'comment-time';
            time.textContent = formatDate(c.timestamp);

            var body = document.createElement('div');
            body.className = 'comment-body';
            body.textContent = c.message;

            li.appendChild(header);
            li.appendChild(time);
            li.appendChild(body);
            list.appendChild(li);
        });
    }

    function setup() {
        var comments = loadComments();
		var prefs = loadPrefs();
        var form = document.getElementById('contactForm');
        var roleEl = document.getElementById('role');
        var nameEl = document.getElementById('name');
        var msgEl = document.getElementById('message');
        var statusEl = document.getElementById('formStatus');
        var filterEl = document.getElementById('filterRole');
		var submitBtn = document.getElementById('submitBtn');
		var charCount = document.getElementById('charCount');

		// Restore preferences
		if (prefs && roleEl && prefs.role) roleEl.value = prefs.role;
		if (prefs && nameEl && prefs.name) nameEl.value = prefs.name;
		if (prefs && filterEl && prefs.filterRole) filterEl.value = prefs.filterRole;

        function setStatus(text, ok) {
            if (!statusEl) return;
            statusEl.textContent = text || '';
            statusEl.style.color = ok ? '#16a34a' : '#dc2626';
        }

		function validate() {
			var message = (msgEl && msgEl.value.trim()) || '';
			var valid = message.length > 0;
			if (submitBtn) submitBtn.disabled = !valid;
			if (charCount && msgEl) {
				charCount.textContent = msgEl.value.length + '/500';
			}
			return valid;
		}

        if (form) {
            form.addEventListener('submit', function (e) {
                e.preventDefault();
                var role = (roleEl && roleEl.value) || 'Employee';
                var name = (nameEl && nameEl.value.trim()) || '';
                var message = (msgEl && msgEl.value.trim()) || '';

				if (!validate()) {
                    setStatus('Message is required.', false);
                    return;
                }
                if (!name) {
                    name = 'Anonymous';
                }

				// Save preferences
				savePrefs({ role: role, name: nameEl ? nameEl.value : '', filterRole: filterEl ? filterEl.value : 'All' });

                var item = {
                    id: uid(),
                    role: role,
                    name: name,
                    message: message,
                    timestamp: Date.now()
                };
                comments.push(item);
                saveComments(comments);
                render(comments, filterEl ? filterEl.value : 'All');

                if (msgEl) msgEl.value = '';
				validate();
                setStatus('Comment published.', true);
				setTimeout(function () { setStatus('', true); }, 1500);

				// Smooth scroll to comments
				var list = document.getElementById('commentsList');
				if (list && typeof list.scrollIntoView === 'function') {
					list.scrollIntoView({ behavior: 'smooth', block: 'start' });
				}
            });
        }

        if (filterEl) {
            filterEl.addEventListener('change', function () {
				// Persist filter preference
				var p = loadPrefs();
				p.filterRole = filterEl.value;
				savePrefs(p);
                render(comments, filterEl.value);
            });
        }

		if (msgEl) {
			msgEl.addEventListener('input', validate);
			msgEl.addEventListener('keydown', function (e) {
				if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
					form && form.dispatchEvent(new Event('submit', { cancelable: true, bubbles: true }));
				}
			});
		}
		if (roleEl) {
			roleEl.addEventListener('change', function () {
				var p = loadPrefs();
				p.role = roleEl.value;
				savePrefs(p);
			});
		}
		if (nameEl) {
			nameEl.addEventListener('input', function () {
				var p = loadPrefs();
				p.name = nameEl.value;
				savePrefs(p);
			});
		}

        render(comments, filterEl ? filterEl.value : 'All');
		validate();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', setup);
    } else {
        setup();
    }
})();

