# Salary Calculation Feature

## Overview
This feature allows administrators to calculate employee salaries with overtime calculations. The admin can input monthly base salary, overtime hours, and overtime rate to automatically calculate the final salary amount.

## Features

### 1. Salary Calculation Form
- **Employee Selection**: Dropdown to select from available employees
- **Monthly Base Salary**: Input field for the base monthly salary
- **Overtime Hours**: Input field for overtime hours worked (supports decimal values)
- **Overtime Rate**: Input field for overtime rate per hour
- **Automatic Calculation**: Real-time calculation as values are entered
- **Calculate Button**: Manual calculation trigger

### 2. Calculation Logic
```
Final Salary = Monthly Base Salary + (Overtime Hours × Overtime Rate)
```

### 3. Database Changes
New fields added to `salary_payments` table:
- `monthly_salary` (DECIMAL(10,2)): Base monthly salary
- `ot_hours` (DECIMAL(5,2)): Overtime hours worked
- `ot_rate` (DECIMAL(10,2)): Overtime rate per hour
- `ot_amount` (DECIMAL(10,2)): Calculated overtime amount

### 4. Enhanced Salary List View
The salary list now displays:
- Employee ID and Name
- Base Salary
- Overtime Hours
- Overtime Amount
- Total Amount
- Month/Year
- Payment Date
- Status
- Actions

## Files Modified

### Frontend Files
1. **src/5salary/salary pay.html**
   - Added salary calculation section
   - Added calculation JavaScript functions
   - Enhanced form validation

2. **src/5salary/salary.html**
   - Updated table headers to show calculation details
   - Modified table display logic

3. **src/5salary/salary.css**
   - Added styles for calculation section
   - Updated table styling for new columns

### Backend Files
1. **backend/api/salary.php**
   - Added new calculation fields to INSERT statement
   - Enhanced data validation

2. **backend/database/schema.sql**
   - Added new columns to salary_payments table

3. **backend/database/migration_add_salary_calculation_fields.sql**
   - Migration script for existing databases

## Usage Instructions

### For Administrators
1. Navigate to Salary → Pay Salary
2. Select an employee from the dropdown
3. Enter the monthly base salary
4. Enter overtime hours (if any)
5. Enter overtime rate per hour (if any)
6. Click "Calculate Salary" or let it auto-calculate
7. Review the calculated final salary
8. Fill in payment details (month/year, payment date, method, notes)
9. Click "Pay Salary" to save

### Database Migration
If you have an existing database, run the migration script:
```sql
-- Run this in phpMyAdmin or MySQL command line
SOURCE backend/database/migration_add_salary_calculation_fields.sql;
```

## Testing
A test file `test_salary_calculation.html` is provided to test the calculation logic independently.

## Example Calculation
- Monthly Base Salary: $5,000.00
- Overtime Hours: 10 hours
- Overtime Rate: $25.00 per hour
- Overtime Amount: 10 × $25.00 = $250.00
- **Final Salary: $5,000.00 + $250.00 = $5,250.00**

## Validation Rules
- Monthly base salary must be greater than 0
- Overtime hours and rate can be 0 (no overtime)
- Final salary amount must be greater than 0
- All required fields must be filled before submission
- Duplicate payments for the same employee and month are prevented
