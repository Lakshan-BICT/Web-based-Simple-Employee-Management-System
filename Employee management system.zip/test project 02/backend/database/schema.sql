-- Employee Management System Database Schema
-- Run this in phpMyAdmin or MySQL command line

CREATE DATABASE IF NOT EXISTS employee_management;
USE employee_management;

-- Users table (for authentication)
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'employee') NOT NULL DEFAULT 'employee',
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Departments table
CREATE TABLE departments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    dept_id VARCHAR(20) UNIQUE NOT NULL,
    dept_name VARCHAR(100) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Employees table
CREATE TABLE employees (
    id INT AUTO_INCREMENT PRIMARY KEY,
    emp_id VARCHAR(20) UNIQUE NOT NULL,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    mobile VARCHAR(15),
    designation VARCHAR(100),
    department_id INT,
    user_id INT,
    hire_date DATE,
    salary DECIMAL(10,2),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- Leave types table
CREATE TABLE leave_types (
    id INT AUTO_INCREMENT PRIMARY KEY,
    type_name VARCHAR(50) NOT NULL,
    max_days INT DEFAULT 0,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Leave requests table
CREATE TABLE leave_requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    employee_id INT NOT NULL,
    leave_type_id INT NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    total_days INT NOT NULL,
    reason TEXT,
    status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    approved_by INT,
    approved_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
    FOREIGN KEY (leave_type_id) REFERENCES leave_types(id),
    FOREIGN KEY (approved_by) REFERENCES employees(id) ON DELETE SET NULL
);

-- Salary payments table
CREATE TABLE salary_payments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    employee_id INT NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    monthly_salary DECIMAL(10,2) DEFAULT 0,
    ot_hours DECIMAL(5,2) DEFAULT 0,
    ot_rate DECIMAL(10,2) DEFAULT 0,
    ot_amount DECIMAL(10,2) DEFAULT 0,
    payment_date DATE NOT NULL,
    month_year VARCHAR(7) NOT NULL, -- Format: YYYY-MM
    status ENUM('pending', 'paid') DEFAULT 'pending',
    payment_method VARCHAR(50),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
);

-- Insert default data
INSERT INTO users (username, email, password, role) VALUES 
('admin', 'admin@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin'),
('employee1', 'emp1@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'employee');

INSERT INTO departments (dept_id, dept_name, description) VALUES 
('DEPT001', 'Human Resources', 'HR Department'),
('DEPT002', 'Finance', 'Finance and Accounting'),
('DEPT003', 'IT', 'Information Technology'),
('DEPT004', 'Marketing', 'Marketing and Sales');

INSERT INTO leave_types (type_name, max_days, description) VALUES 
('Annual Leave', 21, 'Annual vacation leave'),
('Sick Leave', 10, 'Medical leave'),
('Personal Leave', 5, 'Personal time off'),
('Maternity Leave', 90, 'Maternity leave'),
('Paternity Leave', 14, 'Paternity leave');

INSERT INTO employees (emp_id, first_name, last_name, email, mobile, designation, department_id, user_id, hire_date, salary) VALUES 
('EMP001', 'John', 'Doe', 'john.doe@example.com', '0771234567', 'HR Manager', 1, 1, '2023-01-15', 75000.00),
('EMP002', 'Jane', 'Smith', 'jane.smith@example.com', '0772345678', 'Accountant', 2, 2, '2023-02-20', 55000.00),
('EMP003', 'Mike', 'Johnson', 'mike.johnson@example.com', '0773456789', 'Software Developer', 3, NULL, '2023-03-10', 65000.00);

INSERT INTO leave_requests (employee_id, leave_type_id, start_date, end_date, total_days, reason, status) VALUES 
(1, 1, '2024-01-15', '2024-01-20', 5, 'Annual vacation', 'approved'),
(2, 2, '2024-01-25', '2024-01-26', 2, 'Sick leave', 'pending'),
(3, 1, '2024-02-01', '2024-02-05', 4, 'Family vacation', 'pending');

INSERT INTO salary_payments (employee_id, amount, payment_date, month_year, status) VALUES 
(1, 75000.00, '2024-01-31', '2024-01', 'paid'),
(2, 55000.00, '2024-01-31', '2024-01', 'paid'),
(3, 65000.00, '2024-01-31', '2024-01', 'paid');
