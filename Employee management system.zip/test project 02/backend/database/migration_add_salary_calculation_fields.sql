-- Migration script to add salary calculation fields to existing salary_payments table
-- Run this if you have an existing database without the new calculation fields

USE employee_management;

-- Add new columns for salary calculation
ALTER TABLE salary_payments 
ADD COLUMN monthly_salary DECIMAL(10,2) DEFAULT 0 AFTER amount,
ADD COLUMN ot_hours DECIMAL(5,2) DEFAULT 0 AFTER monthly_salary,
ADD COLUMN ot_rate DECIMAL(10,2) DEFAULT 0 AFTER ot_hours,
ADD COLUMN ot_amount DECIMAL(10,2) DEFAULT 0 AFTER ot_rate;

-- Update existing records to set monthly_salary = amount (assuming existing amounts were base salaries)
UPDATE salary_payments SET monthly_salary = amount WHERE monthly_salary = 0;
