<?php
require_once 'config/config.php';

header('Content-Type: application/json');

try {
    // Check if leave types already exist
    $stmt = $db->query("SELECT COUNT(*) as count FROM leave_types");
    $result = $stmt->fetch();
    
    if ($result['count'] == 0) {
        // Insert leave types
        $leaveTypes = [
            ['Annual Leave', 21, 'Annual vacation leave'],
            ['Sick Leave', 10, 'Medical leave'],
            ['Personal Leave', 5, 'Personal time off'],
            ['Maternity Leave', 90, 'Maternity leave'],
            ['Paternity Leave', 14, 'Paternity leave'],
            ['Emergency Leave', 3, 'Emergency situations'],
            ['Study Leave', 7, 'Educational purposes'],
            ['Bereavement Leave', 5, 'Death of family member']
        ];
        
        $stmt = $db->prepare("INSERT INTO leave_types (type_name, max_days, description) VALUES (?, ?, ?)");
        
        foreach ($leaveTypes as $type) {
            $stmt->execute($type);
        }
        
        echo json_encode([
            'success' => true, 
            'message' => 'Leave types added successfully!',
            'count' => count($leaveTypes)
        ]);
    } else {
        // Get existing leave types
        $stmt = $db->query("SELECT * FROM leave_types ORDER BY type_name");
        $types = $stmt->fetchAll();
        
        echo json_encode([
            'success' => true, 
            'message' => 'Leave types already exist',
            'count' => $result['count'],
            'data' => $types
        ]);
    }
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false, 
        'message' => 'Error: ' . $e->getMessage()
    ]);
}
?>
