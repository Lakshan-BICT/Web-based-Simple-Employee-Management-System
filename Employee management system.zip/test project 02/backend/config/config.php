<?php
// Application configuration
define('APP_NAME', 'Employee Management System');
define('APP_VERSION', '1.0.0');
define('APP_URL', 'http://localhost/employee-management');

// Security settings
define('PASSWORD_MIN_LENGTH', 6);
define('SESSION_TIMEOUT', 3600); // 1 hour

// File upload settings
define('UPLOAD_MAX_SIZE', 5 * 1024 * 1024); // 5MB
define('ALLOWED_EXTENSIONS', ['jpg', 'jpeg', 'png', 'pdf', 'doc', 'docx']);

// Pagination settings
define('RECORDS_PER_PAGE', 10);

// Date format
define('DATE_FORMAT', 'Y-m-d');
define('DATETIME_FORMAT', 'Y-m-d H:i:s');

// Error reporting (set to 0 in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Timezone
date_default_timezone_set('Asia/Colombo');

// Include database configuration
require_once __DIR__ . '/database.php';

// Create global database connection
$db = getDB();
?>
