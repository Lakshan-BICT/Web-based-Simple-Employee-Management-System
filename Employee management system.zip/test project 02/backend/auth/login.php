<?php
require_once '../config/config.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$username = $input['username'] ?? '';
$password = $input['password'] ?? '';

// Validate input
if (empty($username) || empty($password)) {
    echo json_encode(['success' => false, 'message' => 'Username and password are required']);
    exit;
}

try {
    $db = getDB();
    
    // Get user from database
    $stmt = $db->prepare("SELECT id, username, email, password, role, is_active FROM users WHERE username = ? AND is_active = 1");
    $stmt->execute([$username]);
    $user = $stmt->fetch();
    
    if ($user && password_verify($password, $user['password'])) {
        // Login successful
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['email'] = $user['email'];
        $_SESSION['role'] = $user['role'];
        $_SESSION['login_time'] = time();
        
        // Get employee details if user is an employee
        if ($user['role'] === 'employee') {
            $stmt = $db->prepare("SELECT emp_id, first_name, last_name, designation, department_id FROM employees WHERE user_id = ?");
            $stmt->execute([$user['id']]);
            $employee = $stmt->fetch();
            
            if ($employee) {
                $_SESSION['emp_id'] = $employee['emp_id'];
                $_SESSION['employee_name'] = $employee['first_name'] . ' ' . $employee['last_name'];
                $_SESSION['designation'] = $employee['designation'];
                $_SESSION['department_id'] = $employee['department_id'];
            }
        }
        
        echo json_encode([
            'success' => true, 
            'message' => 'Login successful',
            'user' => [
                'id' => $user['id'],
                'username' => $user['username'],
                'email' => $user['email'],
                'role' => $user['role']
            ],
            'redirect' => $user['role'] === 'admin' ? '../src/1dashboard/Dashboard.html' : '../src/2employee/employee_dashboard.html'
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Invalid username or password']);
    }
    
} catch (Exception $e) {
    error_log("Login error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Login failed. Please try again.']);
}
?>
