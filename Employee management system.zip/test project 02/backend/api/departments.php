<?php
require_once '../config/config.php';

header('Content-Type: application/json');

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit;
}

// For GET requests, allow both admin and employee access
// For other operations (POST, PUT, DELETE), only allow admin access
$method = $_SERVER['REQUEST_METHOD'];
if ($method !== 'GET' && $_SESSION['role'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Admin access required']);
    exit;
}

$db = getDB();

switch ($method) {
    case 'GET':
        // Get all departments or specific department
        $id = $_GET['id'] ?? null;
        
        if ($id) {
            // Get specific department
            $stmt = $db->prepare("SELECT * FROM departments WHERE id = ?");
            $stmt->execute([$id]);
            $department = $stmt->fetch();
            
            if ($department) {
                // Get employee count for this department
                $stmt = $db->prepare("SELECT COUNT(*) as emp_count FROM employees WHERE department_id = ? AND is_active = 1");
                $stmt->execute([$id]);
                $emp_count = $stmt->fetch()['emp_count'];
                $department['emp_count'] = $emp_count;
                
                echo json_encode(['success' => true, 'data' => $department]);
            } else {
                echo json_encode(['success' => false, 'message' => 'Department not found']);
            }
        } else {
            // Get all departments with employee count
            $stmt = $db->prepare("
                SELECT d.*, COUNT(e.id) as emp_count 
                FROM departments d 
                LEFT JOIN employees e ON d.id = e.department_id AND e.is_active = 1 
                GROUP BY d.id 
                ORDER BY d.dept_name
            ");
            $stmt->execute();
            $departments = $stmt->fetchAll();
            
            echo json_encode(['success' => true, 'data' => $departments]);
        }
        break;
        
    case 'POST':
        // Create new department
        // Handle both JSON and form data
        $contentType = $_SERVER['CONTENT_TYPE'] ?? '';
        if (strpos($contentType, 'application/json') !== false) {
            $input = json_decode(file_get_contents('php://input'), true);
        } else {
            $input = $_POST;
        }
        
        $dept_name = $input['dept_name'] ?? '';
        $emp_count = (int)($input['emp_count'] ?? 0);
        $description = $input['description'] ?? '';
        
        // Validate required fields
        if (empty($dept_name)) {
            echo json_encode(['success' => false, 'message' => 'Department name is required']);
            exit;
        }
        
        // Auto-generate department ID
        $dept_id = generateDepartmentId($db);
        
        try {
            $stmt = $db->prepare("INSERT INTO departments (dept_id, dept_name, description) VALUES (?, ?, ?)");
            $result = $stmt->execute([$dept_id, $dept_name, $description]);
            
            if ($result) {
                // Get the created department
                $stmt = $db->prepare("SELECT * FROM departments WHERE dept_id = ?");
                $stmt->execute([$dept_id]);
                $department = $stmt->fetch();
                
                echo json_encode([
                    'success' => true, 
                    'message' => 'Department created successfully',
                    'data' => $department
                ]);
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to create department']);
            }
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => 'Error creating department: ' . $e->getMessage()]);
        }
        break;
        
    case 'PUT':
        // Update department
        $input = json_decode(file_get_contents('php://input'), true);
        $id = $input['id'] ?? null;
        
        if (!$id) {
            echo json_encode(['success' => false, 'message' => 'Department ID is required']);
            exit;
        }
        
        $dept_name = $input['dept_name'] ?? '';
        $description = $input['description'] ?? '';
        
        try {
            $stmt = $db->prepare("UPDATE departments SET dept_name = ?, description = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?");
            $result = $stmt->execute([$dept_name, $description, $id]);
            
            if ($result) {
                echo json_encode(['success' => true, 'message' => 'Department updated successfully']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to update department']);
            }
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => 'Error updating department: ' . $e->getMessage()]);
        }
        break;
        
    case 'DELETE':
        // Delete department
        $id = $_GET['id'] ?? null;
        
        if (!$id) {
            echo json_encode(['success' => false, 'message' => 'Department ID is required']);
            exit;
        }
        
        // Check if department has employees
        $stmt = $db->prepare("SELECT COUNT(*) as emp_count FROM employees WHERE department_id = ? AND is_active = 1");
        $stmt->execute([$id]);
        $emp_count = $stmt->fetch()['emp_count'];
        
        if ($emp_count > 0) {
            echo json_encode(['success' => false, 'message' => 'Cannot delete department with active employees']);
            exit;
        }
        
        try {
            $stmt = $db->prepare("DELETE FROM departments WHERE id = ?");
            $result = $stmt->execute([$id]);
            
            if ($result) {
                echo json_encode(['success' => true, 'message' => 'Department deleted successfully']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to delete department']);
            }
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => 'Error deleting department: ' . $e->getMessage()]);
        }
        break;
        
    default:
        http_response_code(405);
        echo json_encode(['success' => false, 'message' => 'Method not allowed']);
        break;
}

// Function to generate department ID
function generateDepartmentId($db) {
    // Get the highest existing department ID
    $stmt = $db->query("SELECT dept_id FROM departments WHERE dept_id LIKE 'DEPT%' ORDER BY dept_id DESC LIMIT 1");
    $result = $stmt->fetch();
    
    if ($result) {
        // Extract the number from the last department ID
        $lastId = $result['dept_id'];
        $number = (int)substr($lastId, 4); // Remove 'DEPT' prefix
        $nextNumber = $number + 1;
    } else {
        // If no departments exist, start with 1
        $nextNumber = 1;
    }
    
    // Format the new ID with leading zeros
    return 'DEPT' . str_pad($nextNumber, 3, '0', STR_PAD_LEFT);
}

?>
