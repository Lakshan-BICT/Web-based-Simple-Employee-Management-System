<?php
require_once '../config/config.php';

header('Content-Type: application/json');

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit;
}

$method = $_SERVER['REQUEST_METHOD'];
$db = getDB();

switch ($method) {
    case 'GET':
        // Get leave requests
        $id = $_GET['id'] ?? null;
        $employee_id = $_GET['employee_id'] ?? null;
        $status = $_GET['status'] ?? null;
        
        if ($id) {
            // Get specific leave request
            $stmt = $db->prepare("
                SELECT lr.*, e.emp_id, e.first_name, e.last_name, lt.type_name 
                FROM leave_requests lr 
                JOIN employees e ON lr.employee_id = e.id 
                JOIN leave_types lt ON lr.leave_type_id = lt.id 
                WHERE lr.id = ?
            ");
            $stmt->execute([$id]);
            $leave = $stmt->fetch();
            
            if ($leave) {
                echo json_encode(['success' => true, 'data' => $leave]);
            } else {
                echo json_encode(['success' => false, 'message' => 'Leave request not found']);
            }
        } else {
            // Get all leave requests (admin) or employee's own requests
            if ($_SESSION['role'] === 'admin') {
                $where_clause = "1=1";
                $params = [];
                
                if ($employee_id) {
                    $where_clause .= " AND lr.employee_id = ?";
                    $params[] = $employee_id;
                }
                
                if ($status) {
                    $where_clause .= " AND lr.status = ?";
                    $params[] = $status;
                }
                
                $stmt = $db->prepare("
                    SELECT lr.*, e.emp_id, e.first_name, e.last_name, lt.type_name 
                    FROM leave_requests lr 
                    JOIN employees e ON lr.employee_id = e.id 
                    JOIN leave_types lt ON lr.leave_type_id = lt.id 
                    WHERE $where_clause 
                    ORDER BY lr.created_at DESC
                ");
                $stmt->execute($params);
            } else {
                // Employee can only see their own requests
                $stmt = $db->prepare("
                    SELECT lr.*, lt.type_name 
                    FROM leave_requests lr 
                    JOIN leave_types lt ON lr.leave_type_id = lt.id 
                    WHERE lr.employee_id = (SELECT id FROM employees WHERE user_id = ?) 
                    ORDER BY lr.created_at DESC
                ");
                $stmt->execute([$_SESSION['user_id']]);
            }
            
            $leaves = $stmt->fetchAll();
            echo json_encode(['success' => true, 'data' => $leaves]);
        }
        break;
        
    case 'POST':
        // Create new leave request
        $input = json_decode(file_get_contents('php://input'), true);
        if (!$input) {
            $input = $_POST;
        }
        
        $leave_type_id = $input['leave_type_id'] ?? $input['leave_type'] ?? null;
        $start_date = $input['start_date'] ?? '';
        $end_date = $input['end_date'] ?? '';
        $reason = $input['reason'] ?? '';
        
        // Validate required fields
        if (!$leave_type_id || empty($start_date) || empty($end_date) || empty($reason)) {
            echo json_encode(['success' => false, 'message' => 'Required fields are missing: leave_type, start_date, end_date, and reason are required']);
            exit;
        }
        
        // Calculate total days
        $start = new DateTime($start_date);
        $end = new DateTime($end_date);
        $total_days = $start->diff($end)->days + 1;
        
        // Get employee ID - handle both logged in users and admin creating for others
        $employee_id = null;
        
        if (isset($_SESSION['user_id'])) {
            // Try to get employee ID from session user
            $stmt = $db->prepare("SELECT id FROM employees WHERE user_id = ?");
            $stmt->execute([$_SESSION['user_id']]);
            $employee = $stmt->fetch();
            
            if ($employee) {
                $employee_id = $employee['id'];
            }
        }
        
        // If no employee found from session, try to get from input (for admin creating leave for others)
        if (!$employee_id && isset($input['employee_id'])) {
            $employee_id = $input['employee_id'];
        }
        
        // If still no employee ID, use the first employee as default (for testing)
        if (!$employee_id) {
            $stmt = $db->query("SELECT id FROM employees LIMIT 1");
            $employee = $stmt->fetch();
            if ($employee) {
                $employee_id = $employee['id'];
            }
        }
        
        if (!$employee_id) {
            echo json_encode(['success' => false, 'message' => 'No employee found. Please ensure there are employees in the system.']);
            exit;
        }
        
        try {
            $stmt = $db->prepare("
                INSERT INTO leave_requests (employee_id, leave_type_id, start_date, end_date, total_days, reason) 
                VALUES (?, ?, ?, ?, ?, ?)
            ");
            $result = $stmt->execute([$employee_id, $leave_type_id, $start_date, $end_date, $total_days, $reason]);
            
            if ($result) {
                echo json_encode(['success' => true, 'message' => 'Leave request submitted successfully']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to submit leave request']);
            }
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => 'Error submitting leave request: ' . $e->getMessage()]);
        }
        break;
        
    case 'PUT':
        // Update leave request (approve/reject)
        if ($_SESSION['role'] !== 'admin') {
            http_response_code(403);
            echo json_encode(['success' => false, 'message' => 'Access denied']);
            exit;
        }
        
        $input = json_decode(file_get_contents('php://input'), true);
        $id = $input['id'] ?? null;
        $status = $input['status'] ?? '';
        
        if (!$id || !in_array($status, ['approved', 'rejected'])) {
            echo json_encode(['success' => false, 'message' => 'Invalid request']);
            exit;
        }
        
        try {
            $stmt = $db->prepare("
                UPDATE leave_requests 
                SET status = ?, approved_by = (SELECT id FROM employees WHERE user_id = ?), approved_at = CURRENT_TIMESTAMP 
                WHERE id = ?
            ");
            $result = $stmt->execute([$status, $_SESSION['user_id'], $id]);
            
            if ($result) {
                echo json_encode(['success' => true, 'message' => 'Leave request ' . $status . ' successfully']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to update leave request']);
            }
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => 'Error updating leave request: ' . $e->getMessage()]);
        }
        break;
        
    case 'DELETE':
        // Delete leave request (only if pending and by the employee who created it)
        $id = $_GET['id'] ?? null;
        
        if (!$id) {
            echo json_encode(['success' => false, 'message' => 'Leave request ID is required']);
            exit;
        }
        
        try {
            if ($_SESSION['role'] === 'admin') {
                $stmt = $db->prepare("DELETE FROM leave_requests WHERE id = ?");
                $result = $stmt->execute([$id]);
            } else {
                $stmt = $db->prepare("
                    DELETE FROM leave_requests 
                    WHERE id = ? AND employee_id = (SELECT id FROM employees WHERE user_id = ?) AND status = 'pending'
                ");
                $result = $stmt->execute([$id, $_SESSION['user_id']]);
            }
            
            if ($result) {
                echo json_encode(['success' => true, 'message' => 'Leave request deleted successfully']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to delete leave request']);
            }
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => 'Error deleting leave request: ' . $e->getMessage()]);
        }
        break;
        
    default:
        http_response_code(405);
        echo json_encode(['success' => false, 'message' => 'Method not allowed']);
        break;
}

// Get leave types
if (isset($_GET['action']) && $_GET['action'] === 'leave_types') {
    $stmt = $db->prepare("SELECT * FROM leave_types ORDER BY type_name");
    $stmt->execute();
    $leave_types = $stmt->fetchAll();
    echo json_encode(['success' => true, 'data' => $leave_types]);
    exit;
}
?>
