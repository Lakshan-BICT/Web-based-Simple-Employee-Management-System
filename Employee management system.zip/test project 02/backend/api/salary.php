<?php
require_once '../config/config.php';

header('Content-Type: application/json');

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit;
}

$method = $_SERVER['REQUEST_METHOD'];
$db = getDB();

switch ($method) {
    case 'GET':
        // Get salary payments
        $id = $_GET['id'] ?? null;
        $employee_id = $_GET['employee_id'] ?? null;
        $month_year = $_GET['month_year'] ?? null;
        
        if ($id) {
            // Get specific salary payment
            $stmt = $db->prepare("
                SELECT sp.*, e.emp_id, e.first_name, e.last_name 
                FROM salary_payments sp 
                JOIN employees e ON sp.employee_id = e.id 
                WHERE sp.id = ?
            ");
            $stmt->execute([$id]);
            $salary = $stmt->fetch();
            
            if ($salary) {
                echo json_encode(['success' => true, 'data' => $salary]);
            } else {
                echo json_encode(['success' => false, 'message' => 'Salary payment not found']);
            }
        } else {
            // Get all salary payments (admin) or employee's own payments
            if ($_SESSION['role'] === 'admin') {
                $where_clause = "1=1";
                $params = [];
                
                if ($employee_id) {
                    $where_clause .= " AND sp.employee_id = ?";
                    $params[] = $employee_id;
                }
                
                if ($month_year) {
                    $where_clause .= " AND sp.month_year = ?";
                    $params[] = $month_year;
                }
                
                $stmt = $db->prepare("
                    SELECT sp.*, e.emp_id, e.first_name, e.last_name 
                    FROM salary_payments sp 
                    JOIN employees e ON sp.employee_id = e.id 
                    WHERE $where_clause 
                    ORDER BY sp.payment_date DESC
                ");
                $stmt->execute($params);
            } else {
                // Employee can only see their own payments
                $stmt = $db->prepare("
                    SELECT sp.* 
                    FROM salary_payments sp 
                    WHERE sp.employee_id = (SELECT id FROM employees WHERE user_id = ?) 
                    ORDER BY sp.payment_date DESC
                ");
                $stmt->execute([$_SESSION['user_id']]);
            }
            
            $salaries = $stmt->fetchAll();
            echo json_encode(['success' => true, 'data' => $salaries]);
        }
        break;
        
    case 'POST':
        // Create new salary payment (admin only)
        if ($_SESSION['role'] !== 'admin') {
            http_response_code(403);
            echo json_encode(['success' => false, 'message' => 'Access denied']);
            exit;
        }
        
        $input = json_decode(file_get_contents('php://input'), true);
        
        // Debug logging
        error_log('Salary payment POST data: ' . json_encode($input));
        
        $employee_id = $input['employee_id'] ?? null;
        $amount = $input['amount'] ?? 0;
        $payment_date = $input['payment_date'] ?? date('Y-m-d');
        $month_year = $input['month_year'] ?? date('Y-m');
        $payment_method = $input['payment_method'] ?? 'Bank Transfer';
        $notes = $input['notes'] ?? '';
        
        // New calculation fields
        $monthly_salary = $input['monthly_salary'] ?? 0;
        $ot_hours = $input['ot_hours'] ?? 0;
        $ot_rate = $input['ot_rate'] ?? 0;
        $ot_amount = $input['ot_amount'] ?? 0;
        
        // Validate required fields
        if (!$employee_id || $amount <= 0) {
            error_log('Validation failed - employee_id: ' . $employee_id . ', amount: ' . $amount);
            echo json_encode(['success' => false, 'message' => 'Employee ID and amount are required']);
            exit;
        }
        
        // Check if payment already exists for this employee and month
        $stmt = $db->prepare("SELECT id FROM salary_payments WHERE employee_id = ? AND month_year = ?");
        $stmt->execute([$employee_id, $month_year]);
        if ($stmt->fetch()) {
            echo json_encode(['success' => false, 'message' => 'Payment already exists for this employee and month']);
            exit;
        }
        
        try {
            // Check if new columns exist, if not use old structure
            $columns_check = $db->query("SHOW COLUMNS FROM salary_payments LIKE 'monthly_salary'");
            if ($columns_check->rowCount() > 0) {
                // New structure with calculation fields
                $stmt = $db->prepare("
                    INSERT INTO salary_payments (employee_id, amount, monthly_salary, ot_hours, ot_rate, ot_amount, payment_date, month_year, payment_method, notes) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ");
                $result = $stmt->execute([$employee_id, $amount, $monthly_salary, $ot_hours, $ot_rate, $ot_amount, $payment_date, $month_year, $payment_method, $notes]);
            } else {
                // Old structure without calculation fields
                $stmt = $db->prepare("
                    INSERT INTO salary_payments (employee_id, amount, payment_date, month_year, payment_method, notes) 
                    VALUES (?, ?, ?, ?, ?, ?)
                ");
                $result = $stmt->execute([$employee_id, $amount, $payment_date, $month_year, $payment_method, $notes]);
            }
            
            if ($result) {
                echo json_encode(['success' => true, 'message' => 'Salary payment created successfully']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to create salary payment']);
            }
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => 'Error creating salary payment: ' . $e->getMessage()]);
        }
        break;
        
    case 'PUT':
        // Update salary payment (admin only)
        if ($_SESSION['role'] !== 'admin') {
            http_response_code(403);
            echo json_encode(['success' => false, 'message' => 'Access denied']);
            exit;
        }
        
        $input = json_decode(file_get_contents('php://input'), true);
        $id = $input['id'] ?? null;
        $status = $input['status'] ?? '';
        
        if (!$id || !in_array($status, ['pending', 'paid'])) {
            echo json_encode(['success' => false, 'message' => 'Invalid request']);
            exit;
        }
        
        try {
            $stmt = $db->prepare("UPDATE salary_payments SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?");
            $result = $stmt->execute([$status, $id]);
            
            if ($result) {
                echo json_encode(['success' => true, 'message' => 'Salary payment updated successfully']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to update salary payment']);
            }
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => 'Error updating salary payment: ' . $e->getMessage()]);
        }
        break;
        
    case 'DELETE':
        // Delete salary payment (admin only)
        if ($_SESSION['role'] !== 'admin') {
            http_response_code(403);
            echo json_encode(['success' => false, 'message' => 'Access denied']);
            exit;
        }
        
        $id = $_GET['id'] ?? null;
        
        if (!$id) {
            echo json_encode(['success' => false, 'message' => 'Salary payment ID is required']);
            exit;
        }
        
        try {
            $stmt = $db->prepare("DELETE FROM salary_payments WHERE id = ?");
            $result = $stmt->execute([$id]);
            
            if ($result) {
                echo json_encode(['success' => true, 'message' => 'Salary payment deleted successfully']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to delete salary payment']);
            }
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => 'Error deleting salary payment: ' . $e->getMessage()]);
        }
        break;
        
    default:
        http_response_code(405);
        echo json_encode(['success' => false, 'message' => 'Method not allowed']);
        break;
}

// Get dashboard statistics
if (isset($_GET['action']) && $_GET['action'] === 'dashboard_stats') {
    if ($_SESSION['role'] !== 'admin') {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'Access denied']);
        exit;
    }
    
    try {
        // Total employees
        $stmt = $db->prepare("SELECT COUNT(*) as total FROM employees WHERE is_active = 1");
        $stmt->execute();
        $total_employees = $stmt->fetch()['total'];
        
        // Total departments
        $stmt = $db->prepare("SELECT COUNT(*) as total FROM departments");
        $stmt->execute();
        $total_departments = $stmt->fetch()['total'];
        
        // Monthly salary total
        $current_month = date('Y-m');
        $stmt = $db->prepare("SELECT SUM(amount) as total FROM salary_payments WHERE month_year = ? AND status = 'paid'");
        $stmt->execute([$current_month]);
        $monthly_salary = $stmt->fetch()['total'] ?? 0;
        
        // Leave statistics
        $stmt = $db->prepare("SELECT status, COUNT(*) as count FROM leave_requests GROUP BY status");
        $stmt->execute();
        $leave_stats = $stmt->fetchAll();
        
        $leave_counts = ['pending' => 0, 'approved' => 0, 'rejected' => 0];
        foreach ($leave_stats as $stat) {
            $leave_counts[$stat['status']] = $stat['count'];
        }
        
        echo json_encode([
            'success' => true,
            'data' => [
                'total_employees' => $total_employees,
                'total_departments' => $total_departments,
                'monthly_salary' => $monthly_salary,
                'leave_counts' => $leave_counts
            ]
        ]);
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Error fetching dashboard stats: ' . $e->getMessage()]);
    }
    exit;
}
?>
