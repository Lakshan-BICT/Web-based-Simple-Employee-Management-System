<?php
// Clean Dashboard Stats API
// This is a dedicated endpoint for dashboard statistics

// Start output buffering to catch any unwanted output
ob_start();

// Set error reporting
error_reporting(E_ALL);
ini_set('display_errors', 0); // Don't display errors in output
ini_set('log_errors', 1); // Log errors instead

// Include config
require_once '../config/config.php';

// Set JSON header
header('Content-Type: application/json');

try {
    // Check if user is logged in and is admin
    if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'Access denied - Admin required']);
        exit;
    }
    
    // Get database connection
    $db = getDB();
    if (!$db) {
        throw new Exception('Database connection failed');
    }
    
    // Total employees
    $stmt = $db->prepare("SELECT COUNT(*) as total FROM employees WHERE is_active = 1");
    $stmt->execute();
    $total_employees = $stmt->fetch()['total'];
    
    // Total departments
    $stmt = $db->prepare("SELECT COUNT(*) as total FROM departments");
    $stmt->execute();
    $total_departments = $stmt->fetch()['total'];
    
    // Monthly salary total
    $current_month = date('Y-m');
    $stmt = $db->prepare("SELECT SUM(amount) as total FROM salary_payments WHERE month_year = ? AND status = 'paid'");
    $stmt->execute([$current_month]);
    $monthly_salary = $stmt->fetch()['total'] ?? 0;
    
    // Leave statistics
    $stmt = $db->prepare("SELECT status, COUNT(*) as count FROM leave_requests GROUP BY status");
    $stmt->execute();
    $leave_stats = $stmt->fetchAll();
    
    $leave_counts = ['pending' => 0, 'approved' => 0, 'rejected' => 0];
    foreach ($leave_stats as $stat) {
        $leave_counts[$stat['status']] = $stat['count'];
    }
    
    // Clear any output buffer content
    ob_clean();
    
    // Return JSON response
    echo json_encode([
        'success' => true,
        'data' => [
            'total_employees' => (int)$total_employees,
            'total_departments' => (int)$total_departments,
            'monthly_salary' => (float)$monthly_salary,
            'leave_counts' => $leave_counts
        ]
    ]);
    
} catch (Exception $e) {
    // Clear any output buffer content
    ob_clean();
    
    // Log the error
    error_log('Dashboard stats error: ' . $e->getMessage());
    
    // Return error response
    http_response_code(500);
    echo json_encode([
        'success' => false, 
        'message' => 'Error fetching dashboard stats: ' . $e->getMessage()
    ]);
}

// End output buffering
ob_end_flush();
?>
