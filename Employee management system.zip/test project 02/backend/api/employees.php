<?php
require_once '../config/config.php';

header('Content-Type: application/json');

// Function to generate random password
function generateRandomPassword($length = 8) {
    $characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $password = '';
    for ($i = 0; $i < $length; $i++) {
        $password .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $password;
}

// Function to generate employee ID
function generateEmployeeId($db) {
    $attempts = 0;
    $maxAttempts = 1000; // Prevent infinite loop
    
    do {
        // Get the highest existing employee ID
        $stmt = $db->query("SELECT emp_id FROM employees ORDER BY emp_id DESC LIMIT 1");
        $result = $stmt->fetch();
        
        if ($result) {
            // Extract number from existing ID (e.g., EMP001 -> 1)
            $lastNumber = intval(substr($result['emp_id'], 3));
            $newNumber = $lastNumber + 1;
        } else {
            // First employee
            $newNumber = 1;
        }
        
        // Format as EMP001, EMP002, etc.
        $newEmpId = 'EMP' . str_pad($newNumber, 3, '0', STR_PAD_LEFT);
        
        // Check if this ID already exists (double-check)
        $stmt = $db->prepare("SELECT id FROM employees WHERE emp_id = ?");
        $stmt->execute([$newEmpId]);
        
        if (!$stmt->fetch()) {
            // ID is unique, return it
            return $newEmpId;
        }
        
        $attempts++;
    } while ($attempts < $maxAttempts);
    
    // Fallback: use timestamp if we can't find a unique ID
    return 'EMP' . date('YmdHis');
}

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit;
}

$method = $_SERVER['REQUEST_METHOD'];
$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['role'];
$db = getDB();

switch ($method) {
    case 'GET':
        // Get all employees or specific employee
        $id = $_GET['id'] ?? null;
        
        if ($id) {
            // Get specific employee
            $stmt = $db->prepare("
                SELECT e.*, d.dept_name as department_name, u.username, u.email as user_email 
                FROM employees e 
                LEFT JOIN departments d ON e.department_id = d.id 
                LEFT JOIN users u ON e.user_id = u.id 
                WHERE e.id = ?
            ");
            $stmt->execute([$id]);
            $employee = $stmt->fetch();
            
            if ($employee) {
                echo json_encode(['success' => true, 'data' => $employee]);
            } else {
                echo json_encode(['success' => false, 'message' => 'Employee not found']);
            }
        } else {
            // Get all employees with pagination
            $page = (int)($_GET['page'] ?? 1);
            $limit = (int)RECORDS_PER_PAGE;
            $offset = ($page - 1) * $limit;
            
            $stmt = $db->prepare("
                SELECT e.*, d.dept_name as department_name, u.username 
                FROM employees e 
                LEFT JOIN departments d ON e.department_id = d.id 
                LEFT JOIN users u ON e.user_id = u.id 
                WHERE e.is_active = 1 
                ORDER BY e.created_at DESC 
                LIMIT $limit OFFSET $offset
            ");
            $stmt->execute();
            $employees = $stmt->fetchAll();
            
            // Get total count
            $stmt = $db->prepare("SELECT COUNT(*) as total FROM employees WHERE is_active = 1");
            $stmt->execute();
            $total = $stmt->fetch()['total'];
            
            echo json_encode([
                'success' => true, 
                'data' => $employees,
                'pagination' => [
                    'current_page' => $page,
                    'total_pages' => ceil($total / $limit),
                    'total_records' => $total
                ]
            ]);
        }
        break;
        
    case 'POST':
        // Create new employee
        $input = json_decode(file_get_contents('php://input'), true);
        
        // Auto-generate employee ID
        $emp_id = generateEmployeeId($db);
        $first_name = $input['first_name'] ?? '';
        $last_name = $input['last_name'] ?? '';
        $email = $input['email'] ?? '';
        $mobile = $input['mobile'] ?? '';
        $designation = $input['designation'] ?? '';
        $department_id = $input['department_id'] ?? null;
        $hire_date = $input['hire_date'] ?? date('Y-m-d');
        $salary = $input['salary'] ?? 0;
        
        // Validate required fields
        if (empty($first_name) || empty($last_name) || empty($email)) {
            echo json_encode(['success' => false, 'message' => 'Required fields are missing']);
            exit;
        }
        
        // Check if email already exists
        $stmt = $db->prepare("SELECT id FROM employees WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            echo json_encode(['success' => false, 'message' => 'Email already exists']);
            exit;
        }
        
        try {
            // Generate username and password
            $username = strtolower($first_name . '.' . $last_name);
            $username = preg_replace('/[^a-z0-9.]/', '', $username); // Remove special characters
            
            // Check if username already exists and make it unique
            $original_username = $username;
            $counter = 1;
            do {
                $stmt = $db->prepare("SELECT id FROM users WHERE username = ?");
                $stmt->execute([$username]);
                if ($stmt->fetch()) {
                    $username = $original_username . $counter;
                    $counter++;
                } else {
                    break;
                }
            } while (true);
            
            // Generate a random password
            $password = generateRandomPassword();
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            
            // Start transaction
            $db->beginTransaction();
            
            // Create user account
            $stmt = $db->prepare("
                INSERT INTO users (username, email, password, role) 
                VALUES (?, ?, ?, 'employee')
            ");
            $user_result = $stmt->execute([$username, $email, $hashed_password]);
            
            if (!$user_result) {
                throw new Exception("Failed to create user account");
            }
            
            $user_id = $db->lastInsertId();
            
            // Create employee record
            $stmt = $db->prepare("
                INSERT INTO employees (emp_id, first_name, last_name, email, mobile, designation, department_id, hire_date, salary, user_id) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $employee_result = $stmt->execute([$emp_id, $first_name, $last_name, $email, $mobile, $designation, $department_id, $hire_date, $salary, $user_id]);
            
            if (!$employee_result) {
                throw new Exception("Failed to create employee record");
            }
            
            // Commit transaction
            $db->commit();
            
            echo json_encode([
                'success' => true, 
                'message' => 'Employee created successfully',
                'credentials' => [
                    'username' => $username,
                    'password' => $password,
                    'employee_id' => $emp_id,
                    'name' => $first_name . ' ' . $last_name
                ]
            ]);
            
        } catch (Exception $e) {
            // Rollback transaction on error
            $db->rollback();
            echo json_encode(['success' => false, 'message' => 'Error creating employee: ' . $e->getMessage()]);
        }
        break;
        
    case 'PUT':
        // Update employee
        $input = json_decode(file_get_contents('php://input'), true);
        $id = $input['id'] ?? null;
        
        if (!$id) {
            echo json_encode(['success' => false, 'message' => 'Employee ID is required']);
            exit;
        }
        
        // Check authorization: Admin can update any employee, Employee can only update their own profile
        if ($user_role === 'admin') {
            // Admin can update any employee
        } else {
            // Employee can only update their own profile
            $stmt = $db->prepare("SELECT user_id FROM employees WHERE id = ?");
            $stmt->execute([$id]);
            $employee = $stmt->fetch();
            
            if (!$employee || $employee['user_id'] != $user_id) {
                http_response_code(403);
                echo json_encode(['success' => false, 'message' => 'You can only update your own profile']);
                exit;
            }
        }
        
        // Handle both old format (first_name, last_name) and new format (name)
        $name = $input['name'] ?? '';
        $first_name = $input['first_name'] ?? '';
        $last_name = $input['last_name'] ?? '';
        
        // If name is provided, split it into first and last name
        if ($name && !$first_name && !$last_name) {
            $nameParts = explode(' ', $name, 2);
            $first_name = $nameParts[0];
            $last_name = isset($nameParts[1]) ? $nameParts[1] : '';
        }
        
        $email = $input['email'] ?? '';
        $mobile = $input['mobile'] ?? '';
        $designation = $input['designation'] ?? '';
        $department_id = $input['department_id'] ?? $input['department'] ?? null;
        $salary = $input['salary'] ?? 0;
        $date_of_birth = $input['date_of_birth'] ?? null;
        $gender = $input['gender'] ?? null;
        
        // Validate department_id if provided
        if ($department_id && $department_id !== '') {
            $stmt = $db->prepare("SELECT id FROM departments WHERE id = ?");
            $stmt->execute([$department_id]);
            if (!$stmt->fetch()) {
                echo json_encode(['success' => false, 'message' => 'Invalid department selected']);
                exit;
            }
        } else {
            $department_id = null; // Set to null if empty string
        }
        
        try {
            $stmt = $db->prepare("
                UPDATE employees 
                SET first_name = ?, last_name = ?, email = ?, mobile = ?, designation = ?, department_id = ?, salary = ?, date_of_birth = ?, gender = ?, updated_at = CURRENT_TIMESTAMP 
                WHERE id = ?
            ");
            $result = $stmt->execute([$first_name, $last_name, $email, $mobile, $designation, $department_id, $salary, $date_of_birth, $gender, $id]);
            
            if ($result) {
                echo json_encode(['success' => true, 'message' => 'Employee updated successfully']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to update employee']);
            }
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => 'Error updating employee: ' . $e->getMessage()]);
        }
        break;
        
    case 'DELETE':
        // Delete employee (soft delete)
        $id = $_GET['id'] ?? null;
        
        if (!$id) {
            echo json_encode(['success' => false, 'message' => 'Employee ID is required']);
            exit;
        }
        
        try {
            $stmt = $db->prepare("UPDATE employees SET is_active = 0, updated_at = CURRENT_TIMESTAMP WHERE id = ?");
            $result = $stmt->execute([$id]);
            
            if ($result) {
                echo json_encode(['success' => true, 'message' => 'Employee deleted successfully']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to delete employee']);
            }
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => 'Error deleting employee: ' . $e->getMessage()]);
        }
        break;
        
    default:
        http_response_code(405);
        echo json_encode(['success' => false, 'message' => 'Method not allowed']);
        break;
}
?>
