<?php
// Disable error reporting to prevent HTML output
error_reporting(0);
ini_set('display_errors', 0);

ob_start(); // Start output buffering
require_once '../config/config.php';

header('Content-Type: application/json');

try {
    // Check if user is logged in (make it optional for testing)
    if (!isset($_SESSION['user_id'])) {
        // For testing purposes, allow without authentication
        // ob_clean(); // Clean any accidental output before JSON
        // echo json_encode(['success' => false, 'message' => 'Not authenticated']);
        // exit;
    }

    $method = $_SERVER['REQUEST_METHOD'];
    
    switch ($method) {
        case 'GET':
            // Check if table exists first
            $checkTable = $db->query("SHOW TABLES LIKE 'leave_types'");
            if (!$checkTable->fetch()) {
                ob_clean();
                echo json_encode(['success' => false, 'message' => 'leave_types table does not exist. Please run setup first.']);
                exit;
            }
            
            // Get leave types
            $stmt = $db->prepare("SELECT * FROM leave_types ORDER BY type_name");
            $stmt->execute();
            $leave_types = $stmt->fetchAll();
            
            ob_clean(); // Clean any accidental output before JSON
            echo json_encode([
                'success' => true, 
                'data' => $leave_types
            ]);
            break;
            
        case 'POST':
            // Create new leave type
            $input = json_decode(file_get_contents('php://input'), true);
            if (!$input) {
                $input = $_POST;
            }
            
            $type_name = $input['type_name'] ?? '';
            $max_days = (int)($input['max_days'] ?? 0);
            $description = $input['description'] ?? '';
            
            if (empty($type_name) || $max_days <= 0) {
                ob_clean();
                echo json_encode(['success' => false, 'message' => 'Type name and max days are required']);
                exit;
            }
            
            // Check if table exists first
            $checkTable = $db->query("SHOW TABLES LIKE 'leave_types'");
            if (!$checkTable->fetch()) {
                ob_clean();
                echo json_encode(['success' => false, 'message' => 'leave_types table does not exist. Please run setup first.']);
                exit;
            }
            
            $stmt = $db->prepare("INSERT INTO leave_types (type_name, max_days, description) VALUES (?, ?, ?)");
            $result = $stmt->execute([$type_name, $max_days, $description]);
            
            if ($result) {
                $newId = $db->lastInsertId();
                ob_clean();
                echo json_encode([
                    'success' => true, 
                    'message' => 'Leave type created successfully',
                    'data' => ['id' => $newId, 'type_name' => $type_name, 'max_days' => $max_days, 'description' => $description]
                ]);
            } else {
                ob_clean();
                echo json_encode(['success' => false, 'message' => 'Failed to create leave type: ' . implode(', ', $stmt->errorInfo())]);
            }
            break;
            
        case 'PUT':
            // Update leave type
            $id = $_GET['id'] ?? null;
            if (!$id) {
                ob_clean();
                echo json_encode(['success' => false, 'message' => 'ID is required']);
                exit;
            }
            
            $input = json_decode(file_get_contents('php://input'), true);
            if (!$input) {
                parse_str(file_get_contents('php://input'), $input);
            }
            
            $type_name = $input['type_name'] ?? '';
            $max_days = (int)($input['max_days'] ?? 0);
            $description = $input['description'] ?? '';
            
            if (empty($type_name) || $max_days <= 0) {
                ob_clean();
                echo json_encode(['success' => false, 'message' => 'Type name and max days are required']);
                exit;
            }
            
            $stmt = $db->prepare("UPDATE leave_types SET type_name = ?, max_days = ?, description = ? WHERE id = ?");
            $result = $stmt->execute([$type_name, $max_days, $description, $id]);
            
            if ($result) {
                ob_clean();
                echo json_encode([
                    'success' => true, 
                    'message' => 'Leave type updated successfully'
                ]);
            } else {
                ob_clean();
                echo json_encode(['success' => false, 'message' => 'Failed to update leave type']);
            }
            break;
            
        case 'DELETE':
            // Delete leave type
            $id = $_GET['id'] ?? null;
            if (!$id) {
                ob_clean();
                echo json_encode(['success' => false, 'message' => 'ID is required']);
                exit;
            }
            
            $stmt = $db->prepare("DELETE FROM leave_types WHERE id = ?");
            $result = $stmt->execute([$id]);
            
            if ($result) {
                ob_clean();
                echo json_encode([
                    'success' => true, 
                    'message' => 'Leave type deleted successfully'
                ]);
            } else {
                ob_clean();
                echo json_encode(['success' => false, 'message' => 'Failed to delete leave type']);
            }
            break;
            
        default:
            ob_clean();
            echo json_encode(['success' => false, 'message' => 'Method not allowed']);
            break;
    }
    
} catch (Exception $e) {
    ob_clean(); // Clean any accidental output before JSON
    echo json_encode([
        'success' => false, 
        'message' => 'Error: ' . $e->getMessage()
    ]);
}

exit;
?>
