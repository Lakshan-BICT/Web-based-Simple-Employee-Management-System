# 🗺️ Navigation Guide - Employee Management System

## 📁 Project Structure

```
test project/
├── 📄 index.html                    ← MAIN ENTRY POINT (Start here!)
├── 📁 public/                       ← Public pages and assets
│   ├── 🏠 1Home.html               ← Original home page (now replaced by index.html)
│   ├── 👨‍💼 2admin.html              ← Admin login page
│   ├── 👥 3employee.html           ← Employee login page
│   ├── ℹ️ 4about.html              ← About page
│   ├── 🛠️ 5service.html            ← Services page
│   ├── 📞 6contact.html            ← Contact page
│   ├── 🔐 7resetpassword.html      ← Password reset page
│   ├── 📝 8registeruser.html       ← User registration page
│   ├── 🎨 commen.css               ← Common styles
│   ├── 🎨 home.css                 ← Home page styles
│   ├── 🎨 style_admin.css          ← Admin page styles
│   ├── 🎨 style_emp.css            ← Employee page styles
│   ├── 📜 commen.js                ← Common JavaScript
│   ├── 📜 script_admin.js          ← Admin page scripts
│   ├── 📜 script_emp.js            ← Employee page scripts
│   └── 🖼️ [images]                 ← All image assets
└── 📁 src/                         ← Core application modules
    ├── 📊 1dashboard/              ← Admin dashboard
    │   └── Dashboard.html
    ├── 👥 2employee/               ← Employee management
    │   ├── employee.html
    │   ├── add employee.html
    │   └── remove.html
    ├── 🏢 3department/             ← Department management
    │   ├── department.html
    │   └── add Department.html
    ├── 🏖️ 4leves/                  ← Leave management
    │   ├── leves.html
    │   ├── apply leave.html
    │   ├── pendin leave.html
    │   ├── approved.html
    │   └── rejected leave.html
    ├── 💰 5salary/                 ← Salary management
    │   ├── salary.html
    │   └── salary pay.html
    └── ⚙️ 6setting/                ← Settings
        ├── setting.html
        ├── profile.html
        └── password.html
```

## 🚀 How to Start

1. **Open `index.html`** in your web browser
2. This is now your main entry point that connects all pages
3. Use the navigation cards to access different sections

## 🔗 Navigation Flow

### From Main Page (index.html):
- **Admin Portal** → `public/2admin.html` → `src/1dashboard/Dashboard.html`
- **Employee Portal** → `public/3employee.html` → Employee dashboard
- **Register** → `public/8registeruser.html`
- **About/Services/Contact** → `public/4about.html`, `public/5service.html`, `public/6contact.html`

### From Admin Dashboard:
- **Dashboard** → Overview and statistics
- **Employees** → Manage employee records
- **Department** → Manage departments
- **Leaves** → Handle leave requests
- **Salary** → Process salary payments
- **Settings** → System configuration
- **Logout** → Returns to `index.html`

## 🎯 Key Features

### ✅ What's Working:
- ✅ Main navigation from index.html
- ✅ Admin and Employee login pages
- ✅ Dashboard with sidebar navigation
- ✅ All module pages (Employee, Department, Leave, Salary, Settings)
- ✅ Dark/Light theme toggle
- ✅ Responsive design
- ✅ Proper back navigation to home

### ⚠️ What Needs Backend:
- 🔄 Actual login authentication
- 🔄 Database connectivity
- 🔄 Form submissions
- 🔄 Search functionality
- 🔄 Data persistence

## 🛠️ Quick Fixes Applied:

1. **Created main `index.html`** - Central entry point
2. **Fixed navigation links** - All pages now link back to index.html
3. **Fixed broken script path** - Corrected absolute path in leaves.html
4. **Fixed HTML syntax** - Corrected malformed anchor tag in salary.html
5. **Enhanced home page** - Added feature cards and better navigation

## 🎨 Styling Notes:

- All pages use `commen.css` for consistent theming
- Dark/Light mode is preserved across all pages
- Responsive design works on mobile and desktop
- Professional UI with hover effects and transitions

## 📱 Usage Instructions:

1. **Start with `index.html`**
2. **Choose your role**: Admin or Employee
3. **Navigate through the system** using the sidebar
4. **Use the logout button** to return to the main page
5. **Toggle themes** using the settings page

Your Employee Management System is now properly connected and ready to use! 🎉
